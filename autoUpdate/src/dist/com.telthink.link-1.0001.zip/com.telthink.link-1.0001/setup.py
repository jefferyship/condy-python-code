# -*- coding: utf-8 -*-
'''
Created on 2010-12-20

@author: Condy
'''
from distutils.core import setup   
setup(name='com.telthink.link',   
      version='1.0001',   
      description='call service Util',   
      author='Condy',   
      author_email='linh@ecallcen.com',   
      url='',   
      py_modules=['com.telthink.link.Object','com.telthink.link.pub.ParamUtil'],   
     )
